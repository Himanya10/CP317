//
//  AIPredictionModels.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import Foundation

// MARK: - Stress Forecast
struct StressPrediction: Codable, Identifiable {
    let id = UUID()
    let tomorrowStressScore: Double
    let burnoutRisk: Double
    let optimalRestTime: String
}

// MARK: - Emotion Insights
struct EmotionState: Codable, Identifiable {
    let id = UUID()
    let primaryEmotion: String
    let tensionLevel: Double
    let anxietyProbability: Double
    let fatigueStatus: Double
}

// MARK: - Adaptive Goals
struct AdaptiveGoals: Codable, Identifiable {
    let id = UUID()
    let stepGoal: Int
    let movementGoal: Int
    let recoveryGoal: String
}

// MARK: - Recovery Alarms
struct RecoveryAlarms: Codable, Identifiable {
    let id = UUID()
    let wakeTime: String
    let breakReminders: [String]
    let hydrationTimes: [String]
}

// MARK: - Combined Response Wrapper
struct AIPredictionResponse: Codable {
    let stress: StressPrediction?
    let emotion: EmotionState?
    let goals: AdaptiveGoals?
    let alarms: RecoveryAlarms?
}
