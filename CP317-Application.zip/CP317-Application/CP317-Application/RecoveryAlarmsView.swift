//
//  RecoveryAlarmsView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//
import SwiftUI

struct RecoveryAlarmsView: View {
    
    let suggestedWakeTime = "7:42 AM"
    let hydrationReminder = "Every 90 minutes"
    let breakTime = "Take a 5-minute break every 45 minutes"
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                
                Text("Smart Recovery Alarms")
                    .font(.largeTitle.bold())
                
                AlarmCard(
                    icon: "alarm.fill",
                    title: "Optimal Wake-Up Time",
                    subtitle: suggestedWakeTime,
                    color: .blue
                )
                
                AlarmCard(
                    icon: "drop.fill",
                    title: "Hydration Reminder",
                    subtitle: hydrationReminder,
                    color: .teal
                )
                
                AlarmCard(
                    icon: "figure.walk.motion",
                    title: "Break Timing",
                    subtitle: breakTime,
                    color: .orange
                )
                
                AlarmCard(
                    icon: "brain.head.profile",
                    title: "Stress Reset",
                    subtitle: "Light walk recommended at 3:15 PM",
                    color: .purple
                )
            }
            .padding()
        }
    }
}

struct AlarmCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let color: Color
    
    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
                .padding(10)
                .background(color.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.headline)
                Text(subtitle)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }
}

