//
//  AIModel.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import Foundation

@MainActor
final class AIModel: ObservableObject {
    // MARK: - Singleton
    static let shared = AIModel()
    private init() {}

    // MARK: - Prediction Models
    struct StressPrediction: Codable {
        let predictedStressScore: Double    // 0..100
        let burnoutRisk: Double             // 0..100
        let optimalRestTime: String         // e.g. "9:30 PM"
        let confidence: Double              // 0..1
    }

    struct EmotionInsights: Codable {
        let dominantEmotion: String
        let tensionLevel: Double            // 0..1
        let energyLevel: Double             // 0..1
        let explanation: String
    }

    struct AdaptiveGoals: Codable {
        let stepGoal: Int
        let movementMinutes: Int
        let recoveryNote: String
    }

    struct RecoveryAlarmSet: Codable {
        let bestWakeUpTime: String
        let breakRecommendation: String
        let hydrationSchedule: [String]
        let sleepRecommendation: String
    }

    // MARK: - Observable cached predictions (for UI)
    @Published var cachedStress: StressPrediction?
    @Published var cachedEmotion: EmotionInsights?
    @Published var cachedGoals: AdaptiveGoals?
    @Published var cachedAlarms: RecoveryAlarmSet?
    @Published var lastErrorMessage: String?

    // MARK: - Core (placeholder) inference functions
    // Replace these heuristics with real CoreML / backend LLM calls later.

    func predictStress(hrv: Double, sleepHours: Double, steps: Int) -> StressPrediction {
        // Simple heuristic: lower HRV and less sleep increases stress
        let hrvFactor = max(0.0, min(1.0, (100.0 - hrv) / 100.0))        // 0..1
        let sleepFactor = max(0.0, min(1.0, (8.0 - sleepHours) / 8.0))   // 0..1
        let activityFactor = 1.0 - max(0.0, min(1.0, Double(steps) / 10000.0)) // 0..1 (less steps => slightly higher)
        let stressScore = (hrvFactor * 0.6 + sleepFactor * 0.3 + activityFactor * 0.1) * 100.0

        let burnout = min(100.0, stressScore * 0.9)
        let rest = sleepHours < 7.0 ? "9:30 PM" : "11:00 PM"
        return StressPrediction(predictedStressScore: stressScore, burnoutRisk: burnout, optimalRestTime: rest, confidence: 0.8)
    }

    func analyzeEmotions(hrSpikes: Int, movement: Double, sleepDebt: Double) -> EmotionInsights {
        // Rule-based placeholder
        var emotion = "Calm"
        var tension = 0.1
        var energy = 0.7

        if hrSpikes >= 5 && movement < 0.2 {
            emotion = "Anxiety"
            tension = 0.85
            energy = 0.3
        } else if hrSpikes >= 3 && sleepDebt > 2.0 {
            emotion = "Tension"
            tension = 0.6
            energy = 0.4
        } else if sleepDebt > 4.0 {
            emotion = "Fatigue"
            tension = 0.45
            energy = 0.25
        } else if movement > 0.7 && hrSpikes < 2 {
            emotion = "Energized"
            tension = 0.15
            energy = 0.9
        }

        let explanation = "Estimated from HR spike count, movement and sleep debt."
        return EmotionInsights(dominantEmotion: emotion, tensionLevel: tension, energyLevel: energy, explanation: explanation)
    }

    func generateAdaptiveGoals(yesterdayFatigue: Double, sleepQuality: Double, todaysPerformance: Double) -> AdaptiveGoals {
        // Scores are 0..1 where higher is better
        let baseSteps = 8000.0
        let modifier = 0.5 * (1.0 - yesterdayFatigue) + 0.3 * sleepQuality + 0.2 * todaysPerformance
        let steps = Int(max(3000.0, min(15000.0, baseSteps * max(0.5, min(1.3, modifier)))))
        let move = Int(30.0 * (0.5 + modifier * 0.8))
        let note = "Personalized to be reachable based on recent recovery."
        return AdaptiveGoals(stepGoal: steps, movementMinutes: move, recoveryNote: note)
    }

    func generateRecoveryAlarms(sleepHours: Double, hrv: Double) -> RecoveryAlarmSet {
        let wakeTime = sleepHours < 6.5 ? "7:45 AM" : "6:30 AM"
        let breakRec = hrv < 40 ? "Take a short break every 45 minutes" : "Take a 5–10 minute break every 75 minutes"
        let hydration = ["9:30 AM", "1:00 PM", "4:30 PM"]
        let sleepRec = sleepHours < 7.0 ? "Aim for 7–8 hours tonight." : "Keep current sleep schedule."
        return RecoveryAlarmSet(bestWakeUpTime: wakeTime, breakRecommendation: breakRec, hydrationSchedule: hydration, sleepRecommendation: sleepRec)
    }

    // MARK: - UI sync method (use this to compute & cache predictions)
    @MainActor
    func updateForecast(hrv: Double, sleepMinutes: Double, steps: Int, recentPatternScore: Double) {
        // Convert sleep to hours
        let sleepHours = sleepMinutes / 60.0

        // Compute all AI predictions at once
        let stress = predictStress(hrv: hrv, sleepHours: sleepHours, steps: steps)
        let emotions = analyzeEmotions(hrSpikes: Int(recentPatternScore * 10),
                                       movement: Double(steps) / 10000.0,
                                       sleepDebt: max(0.0, 8.0 - sleepHours))
        let adaptive = generateAdaptiveGoals(yesterdayFatigue: recentPatternScore,
                                             sleepQuality: min(1.0, sleepHours / 8.0),
                                             todaysPerformance: Double(steps) / 10000.0)
        let alarms = generateRecoveryAlarms(sleepHours: sleepHours, hrv: hrv)

        // Save into the singleton (for live UI updates)
        self.cachedStress = stress
        self.cachedEmotion = emotions
        self.cachedGoals = adaptive
        self.cachedAlarms = alarms
    }

    // MARK: - (Optional) async server-backed prediction hook
    // If you later wire a backend LLM, have it decode AIPredictionResponse into these cached properties.
    // Example signature:
    // func requestPredictionsFromBackend(payload: [String:Any]) async { ... }
}
