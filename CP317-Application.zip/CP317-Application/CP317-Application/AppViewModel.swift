//
//  AppViewModel.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//
import Foundation
import Combine

// Shared app-level view model to hold computed metrics and provide mock/demo data.
// In production, this would be fed by HealthKit manager and WatchConnectivity.
class AppViewModel: ObservableObject {
    static let shared = AppViewModel()
    @Published var stressForecast: Double = 0.2
    @Published var optimalRestTime: Date? = Calendar.current.date(byAdding: .minute, value: 30, to: Date())
    @Published var burnoutLikelihood: Double = 0.05
    @Published var currentEmotion: String = "calm"
    @Published var stepsToday: Int = 4200
    @Published var stepsGoal: Int = 8000
    @Published var sleepMinutes: Int = 420
    @Published var weekStress: [Double] = [0.2,0.3,0.45,0.35,0.25,0.2,0.15]
    
    private init() {}
    
    // Small helper to update from AIModel / HealthKit
    func updateFromAI(stress: Double, rest: Date?, burnout: Double) {
        DispatchQueue.main.async {
            self.stressForecast = stress
            self.optimalRestTime = rest
            self.burnoutLikelihood = burnout
        }
    }
}
