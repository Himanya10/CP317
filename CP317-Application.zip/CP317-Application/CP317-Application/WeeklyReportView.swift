//
//  WeeklyReportView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//
import SwiftUI

struct WeeklyReportView: View {
    
    struct DayData: Identifiable {
        let id = UUID()
        let day: String
        let steps: Int
        let stress: Double
        let sleepHours: Double
    }
    
    // Sample weekly dataset — replace with HealthKit real data later
    let weeklyData: [DayData] = [
        .init(day: "Mon", steps: 8200, stress: 0.42, sleepHours: 6.8),
        .init(day: "Tue", steps: 10320, stress: 0.33, sleepHours: 7.4),
        .init(day: "Wed", steps: 6400, stress: 0.55, sleepHours: 6.1),
        .init(day: "Thu", steps: 9100, stress: 0.40, sleepHours: 7.0),
        .init(day: "Fri", steps: 7600, stress: 0.58, sleepHours: 5.9),
        .init(day: "Sat", steps: 12040, stress: 0.29, sleepHours: 8.2),
        .init(day: "Sun", steps: 4500, stress: 0.61, sleepHours: 6.0)
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                
                Text("Weekly Report")
                    .font(.largeTitle.bold())
                    .padding(.bottom, 8)
                
                // Steps Summary Card
                VStack(alignment: .leading, spacing: 16) {
                    Text("Total Weekly Steps")
                        .font(.headline)
                    
                    Text("\(weeklyData.map{$0.steps}.reduce(0,+))")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.green)
                    
                    Text("Average per day: \(weeklyData.map{$0.steps}.reduce(0,+) / 7)")
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                
                // Stress Trend
                VStack(alignment: .leading, spacing: 16) {
                    Text("Stress Trend")
                        .font(.headline)
                    
                    ForEach(weeklyData) { day in
                        HStack {
                            Text(day.day)
                            ProgressView(value: day.stress)
                                .tint(day.stress > 0.55 ? .red : .orange)
                            Text("\(Int(day.stress * 100))%")
                        }
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                
                // Sleep Summary
                VStack(alignment: .leading, spacing: 16) {
                    Text("Sleep Summary")
                        .font(.headline)
                    
                    ForEach(weeklyData) { day in
                        HStack {
                            Text(day.day)
                            Spacer()
                            Text("\(day.sleepHours, specifier: "%.1f")h")
                        }
                    }
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                
                // Navigation links to your new pro-level pages
                VStack(alignment: .leading, spacing: 16) {
                    Text("More Insights")
                        .font(.headline)
                    
                    NavigationLink("Stress Forecast →", destination: StressForecastView())
                    NavigationLink("Emotion Insights →", destination: EmotionInsightsView())
                    NavigationLink("Adaptive Goals →", destination: AdaptiveGoalsView())
                    NavigationLink("Recovery Alarms →", destination: RecoveryAlarmsView())
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(16)
                
                Spacer()
            }
            .padding()
        }
    }
}

