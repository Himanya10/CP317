//
//  EmotionalInsightsView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import SwiftUI

struct EmotionInsightsView: View {
    
    let detectedEmotion = "Tension"
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                
                Text("Emotion Insights")
                    .font(.largeTitle.bold())
                
                VStack(alignment: .leading, spacing: 16) {
                    Text("Detected Emotional State")
                        .font(.headline)
                    
                    Text(detectedEmotion)
                        .font(.system(size: 44, weight: .bold))
                        .foregroundColor(.purple)
                    
                    Text("Based on heart rate spikes, movement patterns, and sleep debt.")
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(LinearGradient(colors: [.purple.opacity(0.4), .purple.opacity(0.15)], startPoint: .top, endPoint: .bottom))
                .cornerRadius(22)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Contributing Factors")
                        .font(.headline)
                    
                    InsightRow(icon: "heart.waveform", label: "Heart Rate Spike Patterns")
                    InsightRow(icon: "bed.double", label: "Sleep Debt")
                    InsightRow(icon: "figure.walk", label: "Movement Patterns")
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                
                Spacer()
            }
            .padding()
        }
    }
}

struct InsightRow: View {
    let icon: String
    let label: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.blue)
            Text(label)
            Spacer()
        }
        .padding(.vertical, 6)
    }
}
