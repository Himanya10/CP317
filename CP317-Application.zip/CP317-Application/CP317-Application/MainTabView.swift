//
//  MainTabView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import SwiftUI

struct MainTabView: View {
    @StateObject var vm = AppViewModel.shared
    
    var body: some View {
        TabView {
            NavigationView {
                DashboardView()
            }
            .tabItem {
                Label("Dashboard", systemImage: "house.fill")
            }
            
            NavigationView {
                StressForecastView()
            }
            .tabItem {
                Label("Stress", systemImage: "waveform.path.ecg")
            }
            
            NavigationView {
                EmotionInsightsView()
            }
            .tabItem {
                Label("Emotions", systemImage: "face.smiling")
            }
            
            NavigationView {
                AdaptiveGoalsView()
            }
            .tabItem {
                Label("Goals", systemImage: "flag.fill")
            }
            
            NavigationView {
                RecoveryAlarmsView()
            }
            .tabItem {
                Label("Recovery", systemImage: "alarm")
            }
            
            NavigationStack {
                WeeklyReportView()
            }

            .tabItem {
                Label("Report", systemImage: "chart.bar.doc.horizontal.fill")
            }
        }
        .accentColor(Color.pgPrimary)
        .onAppear {
            // Sync with AIModel
            AIModel.shared.updateForecast(
                hrv: 55,
                sleepMinutes: Double(vm.sleepMinutes),
                steps: vm.stepsToday,
                recentPatternScore: 0.6
            )
        }

    }
}

struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
