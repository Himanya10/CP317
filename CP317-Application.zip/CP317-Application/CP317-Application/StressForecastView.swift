//
//  StoreForecastView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import SwiftUI

struct StressForecastView: View {
    var hrvToday: Int = 54
    var sleepHours: Double = 6.3
    var steps: Int = 7210
    
    var predictedStress: String = "Moderate"
    var burnoutRisk: Double = 0.37
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                
                Text("Stress Forecast")
                    .font(.largeTitle.bold())
                
                // Main Card
                VStack(alignment: .leading, spacing: 16) {
                    Text("Tomorrow’s Predicted Stress")
                        .font(.headline)
                    
                    Text(predictedStress)
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(predictedStress == "High" ? .red : .orange)
                    
                    ProgressView(value: burnoutRisk)
                        .tint(.red)
                    
                    Text("Burnout Likelihood: \(Int(burnoutRisk * 100))%")
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(20)
                
                // Data Explanation
                VStack(alignment: .leading, spacing: 12) {
                    Text("Based On:")
                        .font(.headline)
                    
                    HStack {
                        Label("HRV: \(hrvToday)", systemImage: "heart.fill")
                        Spacer()
                        Label("Sleep: \(sleepHours, specifier: "%.1f")h", systemImage: "bed.double.fill")
                        Spacer()
                        Label("Steps: \(steps)", systemImage: "figure.walk")
                    }
                    .font(.subheadline)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(16)
                
                Spacer()
            }
            .padding()
        }
    }
}
