//
// DashboardView.swift
// CP317-Application
//
// Created by Himanya Verma on 2025-11-25.
//
import SwiftUI

// --- Color Extensions for Dark Theme Base Colors ---
// We only define the new base colors needed for the dark theme,
// assuming pgPrimary, pgSecondary, etc., are defined elsewhere.
extension Color {
    // Define a black background for the dark theme
    static let darkBackground = Color.black
    // Define a light text color for readability on a dark background
    static let lightText = Color.white
    // A dark color for the card background (slightly lighter than black for contrast)
    static let cardBackground = Color(white: 0.1) // Dark grey for card bodies
    
    // NOTE: Do not redefine pgPrimary, pgSecondary, etc. here.
    // We assume these custom colors are correctly loaded from your assets or other files.
}

// --- Card Style Modifier for Dark Theme ---
// Making a custom modifier to style the cards with a dark background and white text.
// We are renaming 'cardStyle' to 'darkCardStyle' just for this implementation.
// If your original project has 'cardStyle()', you might need to update that instead.
extension View {
    func darkCardStyle() -> some View {
        self.padding()
            .background(Color.cardBackground)
            .foregroundColor(.lightText) // Set all default text inside the card to white
            .cornerRadius(15)
            // Using a slightly more transparent black for the shadow in a dark theme
            .shadow(color: Color.black.opacity(0.5), radius: 5, x: 0, y: 2)
    }
}

// --- Updated Dashboard View ---
struct DashboardView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                // Title
                Text("Today")
                    .font(.largeTitle.bold())
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                    .foregroundColor(.lightText) // White text for the title
                
                // Stress Card
                VStack(alignment: .leading, spacing: 12) {
                    Text("Stress Level")
                        .font(.headline)
                    Text("Moderate")
                        .font(.title.bold())
                        .foregroundColor(.pgPrimary) // Uses existing pgPrimary
                    ProgressView(value: 0.55)
                        .tint(.pgPrimary)
                }
                .darkCardStyle() // Use the new dark card style
                .padding(.horizontal)
                
                // Sleep Card
                VStack(alignment: .leading, spacing: 12) {
                    Text("Sleep Quality")
                        .font(.headline)
                    Text("7h 42m • Good")
                        .font(.title3.bold())
                        .foregroundColor(.pgSecondary) // Uses existing pgSecondary
                    ProgressView(value: 0.72)
                        .tint(.pgSecondary)
                }
                .darkCardStyle() // Use the new dark card style
                .padding(.horizontal)
                
                // Steps Card
                VStack(alignment: .leading, spacing: 12) {
                    Text("Steps")
                        .font(.headline)
                    Text("6,214 / 10,000")
                        .font(.title3.bold())
                        .foregroundColor(.pgAccent) // Uses existing pgAccent
                    ProgressView(value: 6214.0 / 10000.0).tint(.pgAccent)
                }
                .darkCardStyle() // Use the new dark card style
                .padding(.horizontal)
                
                // AI Recommendation
                VStack(alignment: .leading, spacing: 12) {
                    Text("AI Insight")
                        .font(.headline)
                    Text("Your HRV last night was slightly below average. A light walk this afternoon will improve recovery and reduce stress.")
                        .font(.body)
                        // Using a standard secondary color for readability on a dark background
                        .foregroundColor(.secondary)
                }
                .darkCardStyle() // Use the new dark card style
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        // Set the main background to black
        .background(Color.darkBackground.ignoresSafeArea())
    }
}

#Preview {
    DashboardView()
}
