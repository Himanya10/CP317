//
//  AdaptiveGoalsView.swift
//  CP317-Application
//
//  Created by Himanya Verma on 2025-11-25.
//

import SwiftUI

struct AdaptiveGoalsView: View {
    
    var todaysGoal: Int = 8600
    var stepsSoFar: Int = 4213
    
    var progress: Double {
        Double(stepsSoFar) / Double(todaysGoal)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                
                Text("Adaptive Daily Goals")
                    .font(.largeTitle.bold())
                
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Text("Today's Goal")
                            .font(.headline)
                        Spacer()
                        Text("\(todaysGoal) steps")
                            .font(.headline)
                    }
                    
                    ProgressView(value: progress)
                        .tint(.green)
                    
                    HStack {
                        Text("Steps so far:")
                        Spacer()
                        Text("\(stepsSoFar)")
                    }
                    
                    Text("Your goal was adjusted based on yesterday’s fatigue, sleep quality, and early-day performance.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(18)
                
                AdaptiveGoalTips()
            }
            .padding()
        }
    }
}

struct AdaptiveGoalTips: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Why This Goal?")
                .font(.headline)
            Label("You slept 23% below average", systemImage: "bed.double.fill")
            Label("Your early-day energy was moderate", systemImage: "bolt.fill")
            Label("Yesterday fatigue detected", systemImage: "brain.head.profile")
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(16)
    }
}
