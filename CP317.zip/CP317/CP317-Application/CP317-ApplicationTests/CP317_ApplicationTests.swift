//
//  CP317_ApplicationTests.swift
//  CP317-ApplicationTests
//
//  Created by Himanya Verma on 2025-10-28.
//

import Testing
@testable import CP317_Application

struct CP317_ApplicationTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
