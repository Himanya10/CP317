//
//  ReadME.md
//  CP317-Application
//

CP317 Health & Wellness Application
An advanced iOS health application integrating HealthKit and Generative AI (Google Gemini) to provide personalized wellness insights, medication management, and nutrition tracking. This app serves as a comprehensive companion for monitoring stress, recovery, diet, and medication schedules.

📱 Features
1. Dashboard & Biometrics

Centralized Health Hub: View real-time metrics including Steps, Heart Rate, Sleep Duration, and Stress Score.

Vital Signs: Track Blood Pressure, Oxygen Saturation (SpO2), and Body Temperature.

Manual Logging: Quick actions to log water intake, mood, and physical activity.

2. MediVision (Medication Management)

AI Optical Scanning: Scan pill bottles or discharge papers using the camera to automatically extract medication name, dosage, and frequency.

Smart Scheduling: Automatically organizes medications into Morning, Noon, Evening, and Bedtime slots.

PDF Reports: Generate and share printable medication schedules.

Multi-Language Support: Translate schedules into Spanish, French, or Chinese.

3. Nutrition AI Scanner

Visual Food Logging: Take photos of meals to receive instant AI estimates for calories, protein, carbs, fat, and fiber.

Chat Interface: Interact with an AI nutrition assistant to modify logs (e.g., "I removed the bun") and get adjusted macros.

Calorie Tracking: Set daily goals and visualize intake vs. active burn.

4. Stress & Recovery Engine

Predictive Stress Score: Calculates a daily stress score (0-100) using Heart Rate Variability (HRV), sleep quality, and activity data.

Burnout Risk Analysis: Identifies potential exhaustion risks and suggests an "Optimal Rest Time".

Adaptive Recovery: Generates personalized recovery plans including hydration reminders and movement breaks.

🛠 Tech Stack
Language: Swift 5.0

UI Framework: SwiftUI

Data Source: HealthKit (Steps, Heart Rate, Sleep, Vitals)

AI Service: Google Gemini API (gemini-2.5-flash)

Persistence: UserDefaults & JSON

Documents: PDFKit

🚀 Getting Started
Prerequisites

Xcode 16.4 or later

iOS 18.5+ Device (Required for HealthKit and Camera features)

Apple Developer Account (Free or Paid)

Google Gemini API Key

Installation

Clone the Repository

Bash
git clone https://github.com/yourusername/CP317-Application.git
cd CP317-Application
Configure API Key

Locate CP317-Application/Core/Utilities/ConfigTemp.swift.

Rename the file to Config.swift.

Open Config.swift and replace the placeholder with your actual key:

Swift
struct Config {
    static let geminiAPIKey = "YOUR_ACTUAL_GEMINI_API_KEY"
}
Note: Config.swift is added to .gitignore to protect your credentials.

Setup Signing & Capabilities

Open CP317-Application.xcodeproj in Xcode.

Select the CP317-Application target.

Go to the Signing & Capabilities tab.

Bundle Identifier: Change Himanya.CP317-Application to a unique identifier (e.g., com.yourname.CP317-App).

Team: Select your Apple Developer Team.

Ensure HealthKit capability is active.

Run the Application

Connect your physical iPhone (Simulators do not support Camera or full HealthKit data).

Press Cmd + R to build and run.

Grant permissions for Health Access and Camera when prompted.

📂 Project Structure
App: Main entry point and Lifecycle management.

Core:

Models: Data structures for Health, Medication, and AI responses.

Services: API handlers for Gemini and HealthKit managers.

Utilities: Configuration and Theme helpers.

ViewModels: AppViewModel (Global State) and MediVisionViewModel.

Features:

Dashboard: Main dashboard and quick actions.

MediVision: Medication scanning and scheduling views.

Nutrition: Food chat and calorie tracking.

Stress: Stress forecasting and recovery views.

⚠️ Troubleshooting
"Bundle Identifier Cannot be Registered"

This error occurs if the Bundle ID is already taken. Go to Signing & Capabilities and change the Bundle Identifier to something unique.

"Provisioning Profile Expired"

If you see a signing error, clean the build folder (Cmd + Shift + K), verify your Team selection in Signing settings, and try building again to regenerate the profile.

Health Data Not Showing

Ensure you approved all HealthKit permissions on first launch. You can verify this in the iOS Settings app under Health > Sharing > CP317-Application.

📄 License
This project is licensed under the MIT License - see the LICENSE file for details.

