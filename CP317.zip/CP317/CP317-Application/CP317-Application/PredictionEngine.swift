//
//  PredictionEngine.swift
//  CP317-Application
//

import Foundation

@MainActor
final class PredictionEngine: ObservableObject {
    // MARK: - Singleton
    static let shared = PredictionEngine()
    private init() {}
    
    // MARK: - API Configuration
    private let apiKey = Config.geminiAPIKey
    // User requested 2.5-flash endpoint
    private let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    // MARK: - Prediction Models
    struct StressContributors: Codable {
        let sleepImpact: Double
        let heartRateImpact: Double
        let activityImpact: Double
        let moodImpact: Double
        let hrvImpact: Double
    }
    
    struct StressPrediction: Codable {
        let predictedStressScore: Double
        let burnoutRate: Double
        let optimalRestTime: String
        let confidence: Double
        let contributors: StressContributors
        let personalizedRecommendations: [String]
    }

    struct EmotionInsights: Codable {
        let dominantEmotion: String
        let tensionLevel: Double
        let energyLevel: Double
        let explanation: String
    }

    struct AdaptiveGoals: Codable {
        let stepGoal: Int
        let movementMinutes: Int
        let recoveryNote: String
    }

    struct RecoveryAlarmSet: Codable {
        let bestWakeUpTime: String
        let breakRecommendation: String
        let hydrationSchedule: [String]
        let sleepRecommendation: String
    }
    
    // MARK: - AI Response Models
    private struct GeminiExplanationResponse: Codable {
        let explanation: String
    }

    // MARK: - Cached Predictions
    @Published var cachedStress: StressPrediction?
    @Published var cachedEmotion: EmotionInsights?
    @Published var cachedGoals: AdaptiveGoals?
    @Published var cachedAlarms: RecoveryAlarmSet?
    @Published var lastErrorMessage: String?

    // MARK: - Local Heuristic Logic
    
    private func predictStress(hrv: Double, sleepHours: Double, steps: Int, heartRate: Int) -> StressPrediction {
        let hrvScore = max(0, (100.0 - hrv) * 1.5)
        let sleepScore = max(0, (8.0 - sleepHours) * 10.0)
        let stepsScore = Double(steps) / 200.0
        let hrPenalty = max(0.0, Double(heartRate - 75)) * 2.5
        
        let rawScore = hrvScore + sleepScore - stepsScore + hrPenalty
        let stressScore = min(100.0, max(0.0, rawScore * 0.5))
        let calculatedBurnout = min(1.0, stressScore / 80.0)
        
        // CONSTANT OPTIMAL REST TIME LOGIC
        // Targets 10:30 PM tonight, or +30 mins if it's already late
        let now = Date()
        let calendar = Calendar.current
        var targetComponents = calendar.dateComponents([.year, .month, .day], from: now)
        targetComponents.hour = 22
        targetComponents.minute = 30
        let targetDate = calendar.date(from: targetComponents) ?? now
        let finalRestDate = (now > targetDate) ? now.addingTimeInterval(1800) : targetDate
        
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        
        let contributors = StressContributors(
            sleepImpact: min(1.0, sleepScore / 100.0),
            heartRateImpact: min(1.0, hrPenalty / 100.0),
            activityImpact: 1.0 - min(1.0, Double(steps) / 10000.0),
            moodImpact: 0.3,
            hrvImpact: min(1.0, hrvScore / 150.0)
        )
        
        var recommendations: [String] = []
        if sleepHours < 6 { recommendations.append("Prioritize an early bedtime tonight.") }
        if steps < 3000 { recommendations.append("Try a short 10-minute walk.") }
        if recommendations.isEmpty { recommendations.append("Maintain your current healthy routine.") }
        
        return StressPrediction(
            predictedStressScore: stressScore,
            burnoutRate: calculatedBurnout,
            optimalRestTime: formatter.string(from: finalRestDate),
            confidence: 0.7,
            contributors: contributors,
            personalizedRecommendations: recommendations
        )
    }

    private func analyzeEmotions(hrSpikes: Int, movement: Double, sleepDebt: Double) -> EmotionInsights {
        let tension = min(1.0, (Double(hrSpikes) * 0.1) + (sleepDebt * 0.15))
        let energy = min(1.0, max(0.0, movement * 0.5 + (1.0 - tension)))
        
        let emotion: String
        if tension > 0.6 { emotion = "Tension" }
        else if energy > 0.7 { emotion = "Vigorous" }
        else if energy < 0.3 { emotion = "Fatigued" }
        else { emotion = "Calm" }
        
        return EmotionInsights(dominantEmotion: emotion, tensionLevel: tension, energyLevel: energy, explanation: "Based on your recent activity.")
    }

    private func generateAdaptiveGoals(sleepQuality: Double, steps: Int) -> AdaptiveGoals {
        // Improved local logic for "AI Insight" replacement
        var note = "Maintain a balanced routine today."
        
        if sleepQuality < 0.6 {
            note = "Recovery focus: Your sleep was low, so aim for gentle movement."
        } else if steps > 10000 {
            note = "Excellent activity! You're exceeding daily targets."
        } else if steps < 2000 {
            note = "Try to get some steps in to boost your energy levels."
        } else {
            note = "You're on track. Keep consistent with your activity."
        }
        
        return AdaptiveGoals(stepGoal: 8000, movementMinutes: 30, recoveryNote: note)
    }

    private func generateRecoveryAlarms(sleepHours: Double, hrv: Double) -> RecoveryAlarmSet {
        return RecoveryAlarmSet(
            bestWakeUpTime: "7:00 AM",
            breakRecommendation: "Take a break every hour.",
            hydrationSchedule: ["10:00 AM", "2:00 PM"],
            sleepRecommendation: "Aim for 8 hours."
        )
    }

    @MainActor
    func syncHealthData(hrv: Double, sleepMinutes: Double, steps: Int, heartRate: Int, recentPatternScore: Double) {
        let sleepHours = sleepMinutes / 60.0
        let stress = predictStress(hrv: hrv, sleepHours: sleepHours, steps: steps, heartRate: heartRate)
        let emotions = analyzeEmotions(hrSpikes: Int(recentPatternScore * 10), movement: Double(steps)/10000.0, sleepDebt: max(0, 8-sleepHours))
        
        // Updated to use real inputs for the "Insight"
        let adaptive = generateAdaptiveGoals(sleepQuality: min(1, sleepHours/8), steps: steps)
        
        let alarms = generateRecoveryAlarms(sleepHours: sleepHours, hrv: hrv)

        self.cachedStress = stress
        self.cachedEmotion = emotions
        self.cachedGoals = adaptive
        self.cachedAlarms = alarms
    }

    // MARK: - Main Request Method
    func requestPredictionsFromGemini(healthData: HealthData) async {
        // ONLY Run local heuristics.
        // This removes the automatic API call causing 429 errors.
        syncHealthData(
            hrv: healthData.hrvSDNN,
            sleepMinutes: healthData.sleepHours * 60.0,
            steps: healthData.stepCount,
            heartRate: healthData.averageHeartRate,
            recentPatternScore: 0.6
        )
        
        // No fetchGeminiInsight call here anymore.
    }
    
    // MARK: - Interactive Context API Call (Kept for manual taps)
    
    func fetchExplanation(for recommendation: String) async throws -> String {
        let prompt = """
        You are a helpful health assistant.
        Provide a short, 2-sentence explanation of WHY the following recommendation helps with stress or recovery.
        
        Recommendation: "\(recommendation)"
        
        Return ONLY raw JSON with this exact structure:
        {
            "explanation": "Explanation goes here."
        }
        """
        
        let json = try await performGeminiCall(prompt: prompt)
        let response = try JSONDecoder().decode(GeminiExplanationResponse.self, from: json)
        return response.explanation
    }
    
    private func performGeminiCall(prompt: String) async throws -> Data {
        let requestBody: [String: Any] = [
            "contents": [["parts": [["text": prompt]]]],
            "generationConfig": ["temperature": 0.7, "maxOutputTokens": 200],
            "safetySettings": [
                ["category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"],
                ["category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"],
                ["category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"],
                ["category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"]
            ]
        ]
        
        guard let url = URL(string: "\(endpoint)?key=\(apiKey)") else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode != 200 {
            let errorMsg = String(data: data, encoding: .utf8) ?? "Unknown Error"
            print("Gemini API Error (\(httpResponse.statusCode)): \(errorMsg)")
            throw URLError(.badServerResponse)
        }
        
        // Robust Decoding
        let geminiResponse = try JSONDecoder().decode(GeminiAPIResponse.self, from: data)
        
        // 1. Try to get text first (even if flagged)
        if let text = geminiResponse.candidates?.first?.content?.parts?.first?.text, !text.isEmpty {
            let cleanedText = text.replacingOccurrences(of: "```json", with: "")
                                  .replacingOccurrences(of: "```", with: "")
                                  .trimmingCharacters(in: .whitespacesAndNewlines)
            
            if let jsonData = cleanedText.data(using: .utf8) {
                return jsonData
            }
        }
        
        // 2. Check for stop reason
        if let finishReason = geminiResponse.candidates?.first?.finishReason {
            print("Gemini stopped. Reason: \(finishReason)")
        }
        
        throw URLError(.cannotParseResponse)
    }
    
    // Decoding structs
    private struct GeminiAPIResponse: Codable {
        let candidates: [Candidate]?
        struct Candidate: Codable {
            let content: Content?
            let finishReason: String?
        }
        struct Content: Codable {
            let parts: [Part]?
        }
        struct Part: Codable {
            let text: String?
        }
    }
}
