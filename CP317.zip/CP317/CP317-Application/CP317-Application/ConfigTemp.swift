//
//  Config.swift.template
//  CP317-Application
//


import Foundation

struct ConfigTemp {
    // Get your API key from: https://makersuite.google.com/app/apikey
    static let geminiAPIKey = "YOUR_GEMINI_API_KEY_HERE"
}
