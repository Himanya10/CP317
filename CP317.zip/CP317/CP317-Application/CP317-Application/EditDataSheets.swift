//
//  EditDataSheets.swift
//  CP317-Application
//

import SwiftUI

// MARK: - Edit Steps Sheet
struct EditStepsSheet: View {
    @EnvironmentObject var vm: AppViewModel
    @Environment(\.dismiss) var dismiss
    @State private var steps: Double
    
    init(currentSteps: Int) {
        _steps = State(initialValue: Double(currentSteps))
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Current Step Count")) {
                    HStack {
                        Spacer()
                        Text("\(Int(steps))")
                            .font(.system(size: 42, weight: .bold))
                            .foregroundColor(.pgAccent)
                        Spacer()
                    }
                    .padding(.vertical)
                    
                    Slider(value: $steps, in: 0...50000, step: 100)
                        .tint(.pgAccent)
                    
                    HStack {
                        Text("0")
                        Spacer()
                        Text("50,000+")
                    }
                    .font(.caption)
                    .foregroundColor(.secondary)
                }
                
                Section(header: Text("Quick Add")) {
                    HStack(spacing: 20) {
                        Button("+500") { steps += 500 }
                            .buttonStyle(BorderlessButtonStyle())
                        Spacer()
                        Button("+1,000") { steps += 1000 }
                            .buttonStyle(BorderlessButtonStyle())
                        Spacer()
                        Button("+5,000") { steps += 5000 }
                            .buttonStyle(BorderlessButtonStyle())
                    }
                    .foregroundColor(.pgAccent)
                }
                
                Section {
                    Button("Save Steps") {
                        vm.updateSteps(Int(steps))
                        dismiss()
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.pgAccent)
                    .cornerRadius(10)
                }
            }
            .navigationTitle("Edit Steps")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Edit Sleep Sheet
struct EditSleepSheet: View {
    @EnvironmentObject var vm: AppViewModel
    @Environment(\.dismiss) var dismiss
    @State private var sleepHours: Double
    
    init(currentSleep: Double) {
        _sleepHours = State(initialValue: currentSleep)
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section("Sleep Duration") {
                    HStack {
                        Spacer()
                        Text(String(format: "%.1f", sleepHours))
                            .font(.system(size: 42, weight: .bold))
                            .foregroundColor(.purple)
                        Text("hours")
                            .font(.headline)
                            .foregroundColor(.secondary)
                            .padding(.bottom, 8)
                        Spacer()
                    }
                    .padding(.vertical)
                    
                    Slider(value: $sleepHours, in: 0...14, step: 0.5)
                        .tint(.purple)
                }
                
                Button("Save Sleep Data") {
                    vm.updateSleep(hours: sleepHours)
                    dismiss()
                }
                .frame(maxWidth: .infinity)
                .foregroundColor(.white)
                .padding()
                .background(Color.purple)
                .cornerRadius(10)
            }
            .navigationTitle("Edit Sleep")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

// MARK: - Edit Vitals Sheet
struct EditVitalsSheet: View {
    @EnvironmentObject var vm: AppViewModel
    @Environment(\.dismiss) var dismiss
    
    @State private var systolic: String = ""
    @State private var diastolic: String = ""
    @State private var oxygen: Double = 98
    @State private var temperature: Double = 98.6
    
    var body: some View {
        NavigationView {
            Form {
                Section("Blood Pressure (mmHg)") {
                    HStack {
                        TextField("120", text: $systolic)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                        Text("/")
                        TextField("80", text: $diastolic)
                            .keyboardType(.numberPad)
                    }
                }
                
                Section("Oxygen Saturation") {
                    HStack {
                        Text("\(Int(oxygen))%")
                            .foregroundColor(.blue)
                        Slider(value: $oxygen, in: 80...100, step: 1)
                            .tint(.blue)
                    }
                }
                
                Section("Body Temperature (°F)") {
                    HStack {
                        Text(String(format: "%.1f", temperature))
                            .foregroundColor(.orange)
                        Slider(value: $temperature, in: 95...104, step: 0.1)
                            .tint(.orange)
                    }
                }
                
                Button("Save Vitals") {
                    let bpString = (systolic.isEmpty || diastolic.isEmpty) ? vm.bloodPressure : "\(systolic)/\(diastolic)"
                    let o2String = "\(Int(oxygen))%"
                    let tempString = String(format: "%.1f°F", temperature)
                    
                    vm.updateVitals(bp: bpString, o2: o2String, temp: tempString)
                    dismiss()
                }
                .frame(maxWidth: .infinity)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(10)
            }
            .navigationTitle("Edit Vitals")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
        }
    }
}

// MARK: - Edit Energy Sheet
struct EditEnergySheet: View {
    @EnvironmentObject var vm: AppViewModel
    @Environment(\.dismiss) var dismiss
    
    @State private var distance: String = ""
    @State private var activeCal: String = ""
    @State private var totalCal: String = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section("Distance (km)") {
                    TextField("0.0", text: $distance)
                        .keyboardType(.decimalPad)
                }
                Section("Active Calories") {
                    TextField("0", text: $activeCal)
                        .keyboardType(.numberPad)
                }
                Section("Total Calories") {
                    TextField("0", text: $totalCal)
                        .keyboardType(.numberPad)
                }
                
                Button("Save Energy Data") {
                    let d = Double(distance) ?? vm.distanceWalked
                    let ac = Int(activeCal) ?? vm.activeCalories
                    let tc = Int(totalCal) ?? vm.totalCalories
                    vm.updateEnergy(active: ac, total: tc, distance: d)
                    dismiss()
                }
                .frame(maxWidth: .infinity)
                .foregroundColor(.white)
                .padding()
                .background(Color.orange)
                .cornerRadius(10)
            }
            .navigationTitle("Edit Energy")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
            .onAppear {
                distance = String(vm.distanceWalked)
                activeCal = String(vm.activeCalories)
                totalCal = String(vm.totalCalories)
            }
        }
    }
}
