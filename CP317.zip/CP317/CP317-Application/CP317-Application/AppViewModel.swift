//
//  AppViewModel.swift
//  CP317-Application
//

import Foundation
import Combine
import SwiftUI

@MainActor
class AppViewModel: ObservableObject {
    static let shared = AppViewModel()
    
    // Dependencies
    private let healthManager = HealthManager.shared
    private let aiModel = PredictionEngine.shared
    
    // MARK: - Original Published Properties
    @Published var isHealthKitAuthorized = false
    @Published var stepsToday: Int = 0
    @Published var stepsGoal: Int = 8000
    @Published var sleepHoursToday: Double = 0.0
    @Published var currentHeartRate: Int = 0
    
    // MARK: - New Health Metrics
    @Published var bloodPressure: String = "Not enough info"
    @Published var oxygenSaturation: String = "Not enough info"
    @Published var bodyTemperature: String = "Not enough info"
    @Published var activeCalories: Int = 0
    @Published var totalCalories: Int = 0
    @Published var distanceWalked: Double = 0.0
    @Published var workoutMinutes: Int = 0
    
    // Data availability flags
    @Published var hasBloodPressureData: Bool = false
    @Published var hasOxygenData: Bool = false
    @Published var hasTemperatureData: Bool = false
    
    // Loading states
    @Published var isLoadingHealth = false
    @Published var isLoadingPredictions = false
    @Published var lastError: String?
    
    // AI Data properties
    @Published var stressForecastScore: Double = 0.0
    @Published var optimalRestTimeString: String = "--:--"
    @Published var aiInsightText: String = "Gathering health metrics..."
    
    // Mock Data for Weekly Report Chart
    @Published var weekStress: [Double] = [0.2, 0.3, 0.45, 0.35, 0.25, 0.2, 0.15]
    
    // Debouncing
    private var fetchTask: Task<Void, Never>?
    private let fetchDebounceInterval: TimeInterval = 2.0
    
    // Persistence Keys
    private let kStepsOverride = "manual_steps_override"
    private let kSleepOverride = "manual_sleep_override"
    private let kEnergyOverride = "manual_energy_override"
    private let kVitalsOverride = "manual_vitals_override"
    private let kStepsGoal = "daily_step_goal"

    private init() {
        // Load saved goal
        let savedGoal = UserDefaults.standard.integer(forKey: kStepsGoal)
        if savedGoal > 0 { self.stepsGoal = savedGoal }
        
        requestAuthorization()
    }
    
    private func requestAuthorization() {
        healthManager.requestAuthorization { [weak self] success in
            guard let self = self else { return }
            self.isHealthKitAuthorized = success
            if success { self.requestDataAndPredictions() }
        }
    }
    
    /// The main data flow: Fetch HealthKit data, then request AI predictions.
    func requestDataAndPredictions() {
        // Cancel previous task for debouncing
        fetchTask?.cancel()
        
        fetchTask = Task { @MainActor in
            // Add delay for debouncing
            try? await Task.sleep(nanoseconds: UInt64(fetchDebounceInterval * 1_000_000_000))
            
            guard !Task.isCancelled else { return }
            
            isLoadingHealth = true
            lastError = nil
            
            healthManager.fetchLatestMetrics { [weak self] healthData in
                guard let self = self else { return }
                
                // 1. Map original HealthData to UI
                self.stepsToday = healthData.stepCount
                self.sleepHoursToday = healthData.sleepHours
                self.currentHeartRate = healthData.latestHeartRate
                
                // 2. Map new metrics to UI
                self.bloodPressure = healthData.bloodPressureString
                self.oxygenSaturation = healthData.oxygenSaturationString
                self.bodyTemperature = healthData.bodyTemperatureString
                self.activeCalories = healthData.activeCalories
                self.totalCalories = healthData.totalCalories
                self.distanceWalked = healthData.distanceWalked
                self.workoutMinutes = healthData.workoutMinutes
                
                // 3. APPLY MANUAL OVERRIDES (If valid for today)
                self.applyManualOverrides()
                
                // 4. Update availability flags
                self.hasBloodPressureData = (self.bloodPressure != "Not enough info")
                self.hasOxygenData = (self.oxygenSaturation != "Not enough info")
                self.hasTemperatureData = (self.bodyTemperature != "Not enough info")
                
                self.isLoadingHealth = false
                
                // 5. Pass full data to AI
                Task {
                    self.isLoadingPredictions = true
                    // Use current (potentially overridden) values for AI
                    var currentData = healthData
                    currentData.stepCount = self.stepsToday
                    currentData.sleepHours = self.sleepHoursToday
                    // ... pass other overrides if AI needs them
                    
                    await self.aiModel.requestPredictionsFromGemini(healthData: currentData)
                    self.syncAIPredictions()
                    self.isLoadingPredictions = false
                }
            }
        }
    }
    
    /// Syncs data from PredictionEngine's cache to AppViewModel's published properties.
    private func syncAIPredictions() {
        if let stress = aiModel.cachedStress {
            self.stressForecastScore = stress.predictedStressScore
            self.optimalRestTimeString = stress.optimalRestTime
        }
        
        if let goals = aiModel.cachedGoals {
            // Keep manual goal if set, otherwise use AI suggestions
            // self.stepsGoal = goals.stepGoal
            self.aiInsightText = goals.recoveryNote
        }
    }
    
    // MARK: - Manual Update Methods
    
    func updateSteps(_ steps: Int) {
        self.stepsToday = steps
        saveOverride(key: kStepsOverride, value: steps)
    }
    
    func updateStepGoal(_ goal: Int) {
        self.stepsGoal = goal
        UserDefaults.standard.set(goal, forKey: kStepsGoal)
    }
    
    func updateSleep(hours: Double) {
        self.sleepHoursToday = hours
        saveOverride(key: kSleepOverride, value: hours)
    }
    
    func updateVitals(bp: String, o2: String, temp: String) {
        self.bloodPressure = bp
        self.oxygenSaturation = o2
        self.bodyTemperature = temp
        
        self.hasBloodPressureData = !bp.isEmpty && bp != "Not enough info"
        self.hasOxygenData = !o2.isEmpty && o2 != "Not enough info"
        self.hasTemperatureData = !temp.isEmpty && temp != "Not enough info"
        
        let vitalsData: [String: String] = ["bp": bp, "o2": o2, "temp": temp]
        saveOverride(key: kVitalsOverride, value: vitalsData)
    }
    
    func updateEnergy(active: Int, total: Int, distance: Double) {
        self.activeCalories = active
        self.totalCalories = total
        self.distanceWalked = distance
        
        let energyData: [String: Any] = ["active": active, "total": total, "dist": distance]
        saveOverride(key: kEnergyOverride, value: energyData)
    }
    
    // MARK: - Persistence Logic
    
    private func saveOverride(key: String, value: Any) {
        let wrapper: [String: Any] = [
            "date": Date(), // Save timestamp to ensure we only use "today's" manual data
            "value": value
        ]
        UserDefaults.standard.set(wrapper, forKey: key)
    }
    
    private func applyManualOverrides() {
        let calendar = Calendar.current
        
        // Helper to check if override is from today
        func isToday(_ date: Date) -> Bool {
            return calendar.isDateInToday(date)
        }
        
        // 1. Steps
        if let data = UserDefaults.standard.dictionary(forKey: kStepsOverride),
           let date = data["date"] as? Date, isToday(date),
           let steps = data["value"] as? Int {
            self.stepsToday = steps
        }
        
        // 2. Sleep
        if let data = UserDefaults.standard.dictionary(forKey: kSleepOverride),
           let date = data["date"] as? Date, isToday(date),
           let sleep = data["value"] as? Double {
            self.sleepHoursToday = sleep
        }
        
        // 3. Vitals
        if let data = UserDefaults.standard.dictionary(forKey: kVitalsOverride),
           let date = data["date"] as? Date, isToday(date),
           let values = data["value"] as? [String: String] {
            if let bp = values["bp"] { self.bloodPressure = bp }
            if let o2 = values["o2"] { self.oxygenSaturation = o2 }
            if let temp = values["temp"] { self.bodyTemperature = temp }
        }
        
        // 4. Energy
        if let data = UserDefaults.standard.dictionary(forKey: kEnergyOverride),
           let date = data["date"] as? Date, isToday(date),
           let values = data["value"] as? [String: Any] {
            if let active = values["active"] as? Int { self.activeCalories = active }
            if let total = values["total"] as? Int { self.totalCalories = total }
            if let dist = values["dist"] as? Double { self.distanceWalked = dist }
        }
    }
    
    var isStressHigh: Bool { stressForecastScore > 60.0 }
    
    // MARK: - Formatted Strings for Display
    
    var distanceString: String {
        String(format: "%.2f km", distanceWalked)
    }
    
    var activeCaloriesString: String {
        "\(activeCalories) cal"
    }
    
    var totalCaloriesString: String {
        "\(totalCalories) cal"
    }
    
    var workoutTimeString: String {
        if workoutMinutes == 0 {
            return "No workouts today"
        } else if workoutMinutes < 60 {
            return "\(workoutMinutes) min"
        } else {
            let hours = workoutMinutes / 60
            let mins = workoutMinutes % 60
            return "\(hours)h \(mins)m"
        }
    }
    
    // Helper accessors for CalorieDataManager
    var consumedCalories: Int {
        CalorieDataManager.shared.todaysCalories
    }

    var calorieGoal: Int {
        CalorieDataManager.shared.dailyGoal
    }
    
    // MARK: - Preview Helper
    static var preview: AppViewModel {
        let vm = AppViewModel.shared
        vm.stepsToday = 5432
        vm.stepsGoal = 8000
        vm.sleepHoursToday = 7.5
        vm.currentHeartRate = 72
        vm.stressForecastScore = 45.0
        vm.optimalRestTimeString = "10:00 PM"
        vm.aiInsightText = "Your stress levels are moderate today. Consider taking breaks."
        
        // New metrics preview data
        vm.bloodPressure = "120/80"
        vm.oxygenSaturation = "98.5%"
        vm.bodyTemperature = "98.6°F"
        vm.activeCalories = 450
        vm.totalCalories = 1850
        vm.distanceWalked = 5.2
        vm.workoutMinutes = 35
        vm.hasBloodPressureData = true
        vm.hasOxygenData = true
        vm.hasTemperatureData = true
        
        return vm
    }
}
